﻿using Microsoft.AspNetCore.Mvc;

namespace TPBase.Controllers;

public class HomeController : Controller
{
    public IActionResult Index()
    {
        ViewBag.LiPartidos=BD.ListarPartidos();
        return View();
    }
    public IActionResult VerDetallePartido(int idPartido){
        ViewBag.DetallesPartido=BD.VerInfoPartido(idPartido);
        ViewBag.LiCandidatos=BD.ListarCandidatos(idPartido);
        return View ("VerDetallePartido");
    }
    public IActionResult VerDetalleCandidato(int idCandidato){
        ViewBag.DetallesCandidato=BD.VerInfoCandidato(idCandidato);
        return View ("VerDetalleCandidato");
    }
    public IActionResult AgregarCandidato(int idPartido){
        ViewBag.IdPartido=idPartido;
        return View ("AgregarCandidato");
    }
    [HttpPost] public IActionResult GuardarCandidato(Candidato can){
        BD.AgregarCandidato(can);
        return RedirectToAction("VerDetallePartido", new {idPartido = can.IdPartido});
    }
    public IActionResult EliminarCandidato(int idCandidato, int IdPartido){
        BD.EliminarCandidato(idCandidato);
        return RedirectToAction("VerDetallePartido", new {idPartido = IdPartido});
    }
    public IActionResult Elecciones(){
        return View("Elecciones2023");
    }
    public IActionResult Creditos(){
        return View("Creditos");
    }
}
